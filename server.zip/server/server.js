const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));

// Servir archivos estáticos (HTML, CSS, JS) desde la carpeta raíz del proyecto
app.use(express.static(path.join(__dirname, '..')));

// Configurar Nodemailer con Gmail
// Usando contraseña de aplicación (App Password) de Gmail
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'simuladordeexamenes1@gmail.com',
        pass: process.env.GMAIL_APP_PASSWORD || 'tu_contraseña_aplicacion' // Usar variable de entorno
    }
});

// Ruta para enviar sugerencias
app.post('/api/enviar-sugerencia', async (req, res) => {
    try {
        const { 
            grupo, 
            frecuencia, 
            materiasComplicadas, 
            tipoExamen, 
            dificultad, 
            motivo, 
            comentarios, 
            usuarioEmail,
            fecha 
        } = req.body;

        // Validar datos
        if (!grupo) {
            return res.status(400).json({ error: 'El grupo es requerido' });
        }

        // Crear contenido del email
        const asunto = `Nueva Sugerencia - ${grupo}`;
        const contenidoHTML = `
            <h2>Nueva Sugerencia Recibida</h2>
            <hr/>
            <p><strong>Correo del Usuario:</strong> ${usuarioEmail}</p>
            <p><strong>Grupo:</strong> ${grupo}</p>
            <p><strong>Frecuencia de Uso:</strong> ${frecuencia || 'No especificada'}</p>
            <p><strong>Materias Complicadas:</strong> ${materiasComplicadas || 'No especificadas'}</p>
            <p><strong>Tipo de Examen:</strong> ${tipoExamen || 'No especificado'}</p>
            <p><strong>Dificultad:</strong> ${dificultad || 'No especificada'}</p>
            <p><strong>Motivo de Uso:</strong> ${motivo || 'No especificado'}</p>
            <p><strong>Comentarios:</strong></p>
            <p>${comentarios || 'Sin comentarios'}</p>
            <p><strong>Fecha y Hora:</strong> ${fecha}</p>
            <hr/>
            <p style="font-size: 12px; color: #999;">Este es un email automático del Simulador Cecyt 5</p>
        `;

        // Enviar email
        const mailOptions = {
            from: 'simuladordeexamenes1@gmail.com',
            to: 'simuladordeexamenes1@gmail.com',
            subject: asunto,
            html: contenidoHTML
        };

        await transporter.sendMail(mailOptions);

        console.log(`[${new Date().toLocaleString()}] Sugerencia enviada: ${grupo}`);
        res.json({ 
            success: true, 
            message: '✓ Sugerencia guardada y enviada correctamente' 
        });

    } catch (error) {
        console.error('Error al enviar email:', error);
        res.status(500).json({ 
            error: 'Error al enviar la sugerencia', 
            details: error.message 
        });
    }
});

// Ruta de prueba
app.get('/api/salud', (req, res) => {
    res.json({ estado: 'Servidor corriendo', timestamp: new Date() });
});

// Iniciar servidor
app.listen(PORT, () => {
    const hasPass = !!process.env.GMAIL_APP_PASSWORD;
    console.log(`\n🚀 Servidor backend corriendo en http://localhost:${PORT}`);
    console.log(`\n📝 Ruta para enviar sugerencias: POST http://localhost:${PORT}/api/enviar-sugerencia`);
    if (!hasPass) {
        console.log(`\n⚠️  GMAIL_APP_PASSWORD no está configurada. Edita server/.env y reinicia el servidor.`);
    } else {
        console.log(`\n🔑 GMAIL_APP_PASSWORD cargada correctamente.`);
    }
});
